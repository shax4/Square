CREATE DATABASE  IF NOT EXISTS `square_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `square_db`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: j12a307.p.ssafy.io    Database: square_db
-- ------------------------------------------------------
-- Server version	8.4.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `year_of_birth` int NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `updated_at` datetime(6) DEFAULT NULL,
  `nickname` varchar(10) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `s3_key` varchar(255) NOT NULL,
  `age_range` enum('FIFTY','FORTY','TEN','THIRTY','TWENTY') NOT NULL,
  `gender` enum('FEMALE','MALE','NONE') NOT NULL,
  `region` enum('BUSAN','CHUNGBUK','CHUNGNAM','DAEGU','DAEJEON','GANGWON','GWANGJU','GYEONGBUK','GYEONGGI','GYEONGNAM','INCHEON','JEJU','JEONBUK','JEONNAM','SEJONG','SEOUL','ULSAN') NOT NULL,
  `religion` enum('BUDDHISM','CATHOLIC','CHRISTIAN','NONE','OTHER') DEFAULT NULL,
  `social_type` enum('GOOGLE','KAKAO') NOT NULL,
  `state` enum('ACTIVE','ADMIN','INACTIVE','LEAVE') DEFAULT NULL,
  `type` enum('ICSB','ICSR','ICTB','ICTR','INSB','INSR','INTB','INTR','PCSB','PCSR','PCTB','PCTR','PNSB','PNSR','PNTB','PNTR') DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKn4swgcf30j6bmtb4l4cjryuym` (`nickname`),
  UNIQUE KEY `UKob8kqyqqgmefl0aco34akdtpe` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1999,'2025-03-25 12:47:48.135262',1,'2025-03-25 14:20:12.029170','윤다은1호팬','syoon4486@gmail.com','profile/0c643827-c958-465b-875d-918c8a22fe01.png','TWENTY','FEMALE','SEOUL','CHRISTIAN','GOOGLE','ACTIVE','INSB'),(1073741824,'2025-03-25 17:44:59.707583',2,'2025-03-25 17:44:59.707583','eezi','dldmswl956@gmail.com','profile/gyodong2.jpg','FIFTY','MALE','SEOUL','NONE','GOOGLE','ADMIN','INSB'),(2000,'2025-04-01 18:32:47.000000',3,'2025-04-08 02:27:13.447335','반짝이는코알라','test@test.com','profile/leegunhee.jpg','TWENTY','MALE','SEOUL','NONE','GOOGLE','ADMIN','ICTR'),(2000,'2025-04-01 18:32:48.000000',4,'2025-04-01 02:12:48.090621','무거운델피니움','test2@test.com','profile/image33.png','TWENTY','FEMALE','BUSAN','BUDDHISM','GOOGLE','ACTIVE','INSR'),(2000,'2025-04-06 18:32:49.000000',5,'2025-04-07 18:32:37.000000','다크나이트','test3@test.com','profile/honggildong.jpg','TWENTY','MALE','SEOUL','CHRISTIAN','GOOGLE','ADMIN','PNTB'),(2000,'2025-04-07 11:14:49.000000',6,'2025-04-07 11:14:54.000000','떵우기','sjh2395@gmail.com\n','profile/cat.jpg','TWENTY','MALE','SEOUL','CHRISTIAN','GOOGLE','ACTIVE','INSR'),(1995,'2025-04-10 01:24:17.699791',26,'2025-04-10 06:56:35.619675','주노주노','respectwo@gmail.com','profile/ddung2.jpg','THIRTY','MALE','SEOUL','BUDDHISM','GOOGLE','ACTIVE','PCTR'),(1997,'2025-04-10 11:23:10.909346',34,'2025-04-10 12:47:55.535107','애프터썬','alscjf4104@gmail.com','profile/0c643827-c958-465b-875d-918c8a22fe01.png','TWENTY','MALE','SEOUL','BUDDHISM','GOOGLE','ADMIN','INSR'),(1998,'2025-04-10 11:29:27.894204',35,'2025-04-10 11:34:40.845159','플라잉고릴라','baesj1044@gmail.com','profile/0c643827-c958-465b-875d-918c8a22fe01.png','TWENTY','FEMALE','JEJU','BUDDHISM','GOOGLE','ADMIN','INSR'),(1999,'2025-04-11 00:08:40.998416',39,'2025-04-11 02:14:30.967750','주노플로','wkndnight23@gmail.com','profile/ddung2.jpg','TWENTY','MALE','SEOUL','NONE','GOOGLE','ACTIVE','PNSR');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 15:50:04
