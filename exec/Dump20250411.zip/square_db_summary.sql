CREATE DATABASE  IF NOT EXISTS `square_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `square_db`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: j12a307.p.ssafy.io    Database: square_db
-- ------------------------------------------------------
-- Server version	8.4.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `summary`
--

DROP TABLE IF EXISTS `summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `summary` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `is_left` bit(1) NOT NULL,
  `debate_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKkhyorj7l3brpjbnfevj4g1hbf` (`debate_id`),
  CONSTRAINT `FKkhyorj7l3brpjbnfevj4g1hbf` FOREIGN KEY (`debate_id`) REFERENCES `debate` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=519 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `summary`
--

LOCK TABLES `summary` WRITE;
/*!40000 ALTER TABLE `summary` DISABLE KEYS */;
INSERT INTO `summary` VALUES (204,'청소년의 건강한 성장과 범죄로부터의 보호를 위해 일정 시간 이후 외출을 제한해야 합니다.',_binary '',61),(205,'야간은 사고와 유해환경에 노출되기 쉬운 시간대로, 청소년 보호를 위한 제한은 필수적입니다.',_binary '',61),(206,'규칙적인 생활 습관 형성을 위해서는 야간 외출 제한이 장기적으로 도움이 될 수 있습니다.',_binary '',61),(207,'흉악 범죄에 대한 강력한 처벌은 사회 질서를 유지하고 시민의 안전을 지키는 데 필요합니다.',_binary '',62),(208,'사형제는 피해자 유가족에게 최소한의 정의를 제공하고 심리적 안정을 도모할 수 있습니다.',_binary '',62),(209,'범죄 예방을 위한 억제력으로서 사형제는 현재 사회에서도 그 실효성이 입증되고 있습니다.',_binary '',62),(210,'대학 등록금을 무상화하면 저소득층 학생들도 학업에 전념할 수 있는 환경이 조성됩니다.',_binary '',63),(211,'경제적 부담을 줄이면 학생들은 아르바이트 대신 학습과 진로 탐색에 집중할 수 있습니다.',_binary '',63),(212,'국가의 미래 인재 양성을 위해 고등교육 기회는 누구에게나 동등하게 제공되어야 합니다.',_binary '',63),(213,'정년을 연장하면 축적된 경험과 전문성을 가진 고령 인력을 사회가 계속 활용할 수 있습니다.',_binary '',64),(214,'고령화 사회에서 정년 연장은 노동력 부족 문제를 해결할 수 있는 현실적인 대안입니다.',_binary '',64),(215,'퇴직 후 생계 문제를 겪는 고령자에게 정년 연장은 경제적 안정성을 제공할 수 있습니다.',_binary '',64),(216,'주 4일제 도입은 근로자의 삶의 질을 향상시키고 일과 삶의 균형을 실현하는 계기가 됩니다.',_binary '',65),(217,'근무일 감소는 업무 효율을 높이고 피로 누적을 방지해 장기적으로 생산성을 향상시킵니다.',_binary '',65),(218,'짧은 근무일정은 가족 및 자기계발 시간 확보에 기여해 전반적인 삶의 만족도를 높입니다.',_binary '',65),(222,'인터넷 실명제를 통해 악성 댓글과 허위 정보 유포를 근본적으로 차단할 수 있습니다.',_binary '',67),(223,'실명제 도입은 책임 있는 온라인 문화 형성과 사회적 신뢰 회복에 도움이 됩니다.',_binary '',67),(224,'사이버범죄 예방과 피해자 보호를 위해서라도 최소한의 실명 기반은 필요합니다.',_binary '',67),(231,'반려동물 등록을 의무화하면 유기동물 방지와 책임감 있는 반려문화 확산에 기여합니다.',_binary '',70),(232,'등록제도는 반려동물 보호와 정책 수립에 필요한 정확한 데이터를 제공합니다.',_binary '',70),(233,'반려동물을 키우는 모든 시민이 공통된 의무를 지니는 문화가 조성될 수 있습니다.',_binary '',70),(234,'청소년에게 일괄적으로 외출을 제한하는 것은 과도한 통제로 작용할 수 있습니다.',_binary '\0',61),(235,'개인의 상황을 고려하지 않은 외출 제한은 불필요한 반발과 저항을 초래할 수 있습니다.',_binary '\0',61),(236,'가정과 학교에서의 교육이 우선이며, 제도적 강제는 자유를 침해할 우려가 있습니다.',_binary '\0',61),(237,'사형은 국가가 생명을 박탈하는 제도로, 인간의 존엄성을 훼손할 수 있습니다.',_binary '\0',62),(238,'오판 가능성이 있는 현실에서 사형제는 되돌릴 수 없는 치명적 결과를 초래할 수 있습니다.',_binary '\0',62),(239,'종신형과 같은 대체 형벌로도 충분히 사회로부터의 격리는 가능합니다.',_binary '\0',62),(240,'무상 등록금은 막대한 예산이 필요해 장기적으로 재정 부담을 가중시킬 수 있습니다.',_binary '\0',63),(241,'경제적 여유가 있는 계층까지 무상 혜택을 제공하는 것은 형평성에 어긋날 수 있습니다.',_binary '\0',63),(242,'필요한 이들에게 맞춤형 장학금 제도를 강화하는 것이 더 효율적입니다.',_binary '\0',63),(243,'정년 연장은 청년층의 취업 기회를 줄이고 세대 간 갈등을 심화시킬 수 있습니다.',_binary '\0',64),(244,'고령 근로자의 업무 효율과 건강 문제는 조직 운영에 부담을 줄 수 있습니다.',_binary '\0',64),(245,'변화하는 산업 구조에 맞춰 새로운 인재를 유입하는 것이 더 중요할 수 있습니다.',_binary '\0',64),(246,'근무일 축소는 기업 운영에 부담을 주며 생산성 저하를 초래할 수 있습니다.',_binary '\0',65),(247,'서비스업 등 주 4일제가 적용되기 어려운 업종에서 형평성 문제가 발생할 수 있습니다.',_binary '\0',65),(248,'업무량은 그대로인 채 시간만 줄면 오히려 노동 강도가 심화될 수 있습니다.',_binary '\0',65),(252,'실명 강제는 표현의 자유와 익명성이 보장해야 할 민주주의 원칙에 위배됩니다.',_binary '\0',67),(253,'실명제는 소수 의견을 위축시키고 자유로운 토론 문화를 해칠 우려가 있습니다.',_binary '\0',67),(254,'인터넷 실명제는 정부의 과도한 감시로 이어질 수 있어 신중한 접근이 필요합니다.',_binary '\0',67),(261,'등록 의무화는 사생활 침해로 받아들여질 수 있으며 과도한 규제가 될 수 있습니다.',_binary '\0',70),(262,'등록 및 관리 비용이 일부 가정에 경제적 부담으로 작용할 수 있습니다.',_binary '\0',70),(263,'의무 등록보다 자율적 참여를 유도하는 방식이 반감을 줄일 수 있습니다.',_binary '\0',70),(513,'대중교통은 모든 시민들이 필수적으로 이용하는 서비스이므로 기본요금을 무료화하여 경제적 부담을 줄여야 한다.',_binary '',122),(514,'무료화로 인해 대중교통 이용률이 증가하고 자동차 이용량이 감소하여 교통 체증 문제를 완화할 수 있다.',_binary '',122),(515,'저소득층이 대중교통을 무료로 이용할 수 있게 되면 사회적 격차를 줄일 수 있다.',_binary '',122),(516,'대중교통 기본요금을 무료화하면 예산 부담이 커져 다른 사회복지 예산이 부족해질 수 있다.',_binary '\0',122),(517,'무료화로 인해 대중교통 시스템이 지나치게 혼잡해져 서비스 품질이 저하될 우려가 있다.',_binary '\0',122),(518,'무료화로 인해 정상적인 이용자들에게 불이익을 줄 수 있으며, 부정한 이용이 증가할 우려가 있다.',_binary '\0',122);
/*!40000 ALTER TABLE `summary` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 15:50:04
