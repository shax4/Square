CREATE DATABASE  IF NOT EXISTS `square_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `square_db`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: j12a307.p.ssafy.io    Database: square_db
-- ------------------------------------------------------
-- Server version	8.4.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `post_comment`
--

DROP TABLE IF EXISTS `post_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_comment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `like_count` int NOT NULL,
  `is_valid` bit(1) NOT NULL,
  `parent_id` bigint DEFAULT NULL,
  `post_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKmqxhu8q0j94rcly3yxlv0u498` (`parent_id`),
  KEY `FKna4y825fdc5hw8aow65ijexm0` (`post_id`),
  KEY `FKtc1fl97yq74q7j8i08ds731s1` (`user_id`),
  CONSTRAINT `FKmqxhu8q0j94rcly3yxlv0u498` FOREIGN KEY (`parent_id`) REFERENCES `post_comment` (`id`),
  CONSTRAINT `FKna4y825fdc5hw8aow65ijexm0` FOREIGN KEY (`post_id`) REFERENCES `post` (`id`),
  CONSTRAINT `FKtc1fl97yq74q7j8i08ds731s1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_comment`
--

LOCK TABLES `post_comment` WRITE;
/*!40000 ALTER TABLE `post_comment` DISABLE KEYS */;
INSERT INTO `post_comment` VALUES (1,'저도 고등학교 때 상대평가 때문에 친구랑 경쟁하게 돼서 너무 힘들었어요.',5,_binary '',NULL,1,2,NULL,'2025-04-07 08:38:55.405315'),(2,'근데 절대평가로 바뀌면 내신 변별이 더 어려워지지 않을까요?',2,_binary '',NULL,1,3,NULL,NULL),(3,'저도 주 4일제 완전 찬성입니다! 일에 더 집중할 수 있을 것 같아요.',5,_binary '',NULL,2,1,NULL,NULL),(4,'근데 현실적으로 중소기업은 인력 부족 때문에 힘들지도 몰라요.',3,_binary '',NULL,2,4,NULL,NULL),(5,'공감돼요! 저도 글쓰기나 디자인 같은 창작 일 해보고 싶어요.',6,_binary '',NULL,3,5,NULL,NULL),(6,'기본소득이 도입되면 진짜 삶의 방식이 많이 바뀔 것 같네요.',2,_binary '',NULL,3,2,NULL,NULL),(7,'스마트폰은 통제보다 교육이 중요한 것 같아요. 자율을 길러줘야죠.',3,_binary '',NULL,4,5,NULL,NULL),(8,'시간 제한도 좋지만, 부모랑 같이 사용하는 습관부터 바꿔야 한다고 봐요.',1,_binary '',NULL,4,1,NULL,NULL),(9,'완전 공감이요. 강아지 잃어버렸을 때 등록제 덕분에 찾았어요!',7,_binary '',NULL,5,3,NULL,NULL),(10,'근데 등록비나 유지비가 부담된다는 분들도 계시더라고요.',2,_binary '',NULL,5,4,NULL,NULL),(20,'좋은 정보 감사합니다!',3,_binary '',NULL,1,1,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(21,'공감되네요!',5,_binary '',NULL,1,2,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(22,'여기 꼭 가보고 싶어요.',2,_binary '',NULL,2,3,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(23,'사진도 같이 올려주세요!',1,_binary '',NULL,2,4,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(24,'식단 참고할게요.',4,_binary '',NULL,3,5,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(25,'오트밀 진짜 맛있죠 ㅋㅋ',2,_binary '',NULL,39,1,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(26,'매일 하긴 힘들어요 ㅠㅠ',1,_binary '',NULL,4,2,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(27,'저도 도전해볼게요!',3,_binary '',NULL,4,3,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(28,'러닝 코스 공유 감사합니다.',0,_binary '',NULL,39,4,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(29,'저랑 같은 코스네요!',2,_binary '',NULL,5,5,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(30,'네 덕분에 도움 많이 됐어요.',1,_binary '',1,1,1,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(31,'저도 공감이에요!',0,_binary '',2,1,2,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(32,'가보시면 좋아요~',2,_binary '',3,2,3,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(33,'사진 곧 올릴게요!',1,_binary '',4,2,4,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(34,'도움 되셨다니 다행이네요.',3,_binary '',5,3,39,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(35,'ㅋㅋ 진짜 맛있어요',2,_binary '',6,39,1,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(36,'습관이 되면 괜찮아요!',1,_binary '',7,4,2,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(37,'응원합니다!',0,_binary '',8,4,39,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(38,'자주 같이 뛰어요!',2,_binary '',9,5,39,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(39,'오 반가워요~',1,_binary '',10,5,5,'2025-04-04 17:58:54.000000','2025-04-04 17:58:54.000000'),(101,'와 축하드려요!!',0,_binary '',NULL,33,5,'2025-04-11 01:06:13.952524','2025-04-11 01:06:13.952524');
/*!40000 ALTER TABLE `post_comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 15:50:01
