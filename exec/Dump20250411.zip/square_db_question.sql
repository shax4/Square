CREATE DATABASE  IF NOT EXISTS `square_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `square_db`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: j12a307.p.ssafy.io    Database: square_db
-- ------------------------------------------------------
-- Server version	8.4.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `direction` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (1,'P','중요한 결정을 내릴 때, 현실적인 제약과 조건을 먼저 고려하는 편이다.',_binary ''),(2,'I','중요한 결정을 내릴 때, 이상적인 가치와 비전을 우선 고려하는 편이다.',_binary '\0'),(3,'P','목표를 설정할 때, 실행 가능성과 구체적인 계획 수립이 이상적인 비전보다 우선이라고 생각한다.',_binary ''),(4,'I','목표를 설정할 때, 높은 이상과 꿈을 추구하는 것이 실현 가능성보다 더 중요하다고 생각한다.',_binary '\0'),(5,'P','사회 변화는 점진적인 조정과 현실적 접근을 통해 이루어져야 한다고 믿는다.',_binary ''),(6,'I','사회 변화는 급진적인 혁신과 대담한 개혁을 통해 이루어져야 한다고 믿는다.',_binary '\0'),(7,'P','문제 해결 시, 감정보다 객관적인 사실과 데이터에 의존하는 편이다.',_binary ''),(8,'I','성공은 구체적인 계획보다는 영감과 이상을 바탕으로 달성된다고 생각한다.',_binary '\0'),(9,'N','개인의 자유와 선택이 공동체의 조화보다 더 중요하다고 생각한다.',_binary ''),(10,'C','공동체의 조화와 협력이 개인의 자유보다 더 중요한 가치라고 생각한다.',_binary '\0'),(11,'N','자신의 목표와 행복이 집단의 규범보다 우선되어야 한다고 믿는다.',_binary ''),(12,'C','집단의 목표와 가치가 개인의 이익보다 우선되어야 한다고 믿는다.',_binary '\0'),(13,'N','경쟁과 독립적인 판단이 사회 발전에 필수적이라고 생각한다.',_binary ''),(14,'C','타인과의 협력을 통해 사회 문제를 해결하는 것이 바람직하다고 생각한다.',_binary '\0'),(15,'N','개인의 독립적 의사결정이 자신의 성공에 결정적이라고 여긴다.',_binary ''),(16,'C','공동체의 안전과 복지가 개인의 선택보다 우선시되어야 한다고 생각한다.',_binary '\0'),(17,'T','새로운 기술이 사회 발전에 긍정적인 영향을 미친다고 생각한다.',_binary ''),(18,'S','환경 보호와 지속 가능한 발전이 기술 혁신보다 더 중요하다고 생각한다.',_binary '\0'),(19,'T','AI 및 자동화 기술의 발전이 미래 사회에 필수적이라고 믿는다.',_binary ''),(20,'S','자연과 생태계 보존이 미래 사회 번영의 전제 조건이라고 믿는다.',_binary '\0'),(21,'T','우주 개발과 첨단 기술 연구가 경제 성장의 핵심이라고 생각한다.',_binary ''),(22,'S','환경 친화적인 정책이 장기적인 경제 발전의 기초라고 생각한다.',_binary '\0'),(23,'T','기술 혁신이 생활의 편리함과 효율성을 크게 향상시킨다고 믿는다.',_binary ''),(24,'S','기술 발전이 환경 파괴를 초래할 수 있으므로, 환경 보호를 우선시해야 한다고 믿는다.',_binary '\0'),(25,'B','직업 선택 시, 안정적인 환경과 예측 가능한 미래를 가장 중요한 요소로 고려한다.',_binary ''),(26,'R','실패의 가능성이 있더라도 새로운 도전을 통해 성장해야 한다고 생각한다.',_binary '\0'),(27,'B','리스크를 최소화하여 안전한 생활을 유지하는 것이 필요하다고 생각한다.',_binary ''),(28,'R','불확실한 기회라도 도전을 받아들이는 것이 개인 발전에 큰 도움이 된다고 믿는다.',_binary '\0'),(29,'B','예측 가능한 생활 패턴이 불확실한 도전보다 더 가치 있다고 느낀다.',_binary ''),(30,'R','모험적인 선택이 때로는 혁신과 창의성을 촉진한다고 생각한다.',_binary '\0'),(31,'B','일상에서의 규칙성과 안정성이 장기적인 성공의 기반이라고 믿는다.',_binary ''),(32,'R','안정적인 선택보다 때로는 모험적인 결정을 내리는 것이 필요하다고 느낀다.',_binary '\0');
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 15:50:03
