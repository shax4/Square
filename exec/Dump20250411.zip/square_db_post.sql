CREATE DATABASE  IF NOT EXISTS `square_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `square_db`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: j12a307.p.ssafy.io    Database: square_db
-- ------------------------------------------------------
-- Server version	8.4.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `content` varchar(255) NOT NULL,
  `like_count` int NOT NULL,
  `reference_count` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` enum('COMMON','ICSB','ICSR','ICTB','ICTR','INSB','INSR','INTB','INTR','PCSB','PCSR','PCTB','PCTR','PNSB','PNSR','PNTB','PNTR') NOT NULL,
  `is_valid` bit(1) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK72mt33dhhs48hf9gcqrq4fxte` (`user_id`),
  CONSTRAINT `FK72mt33dhhs48hf9gcqrq4fxte` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (1,'2025-04-03 15:37:11.000000','2025-04-07 08:38:55.354888','요즘 절대평가 얘기가 많던데, 저도 수험생일 땐 진짜 상대평가가 너무 스트레스였어요. 바뀌면 좋겠네요.',5,1,'절대평가, 정말 필요할까?','ICSB',_binary '',1),(2,'2025-04-03 15:37:11.000000','2025-04-03 15:37:11.000000','4일 근무제 뉴스 보고 진심 부러웠어요. 일도 삶도 다 챙길 수 있는 그런 환경, 왜 우린 아직도 못할까요?',8,2,'주 4일 근무제, 빨리 됐으면 좋겠어요ㅠㅠ','PNTB',_binary '',2),(3,'2025-04-03 15:37:11.000000','2025-04-03 15:37:11.000000','기본소득이 생기면 전 하고 싶은 공부나 일을 시도해볼 것 같아요. 단지 생존이 아니라 삶을 누리는 느낌?',5,1,'기본소득이 생긴다면 하고 싶은 일','INSR',_binary '',3),(4,'2025-04-03 15:37:11.000000','2025-04-09 09:24:25.890158','아이들이 스마트폰 너무 오래 하는 것 같아서 걱정이에요. 교육적으로 활용하는 건 좋지만, 시간 제한은 필요하지 않을까요?',2,0,'청소년 스마트폰, 어디까지 허용할까?','ICTR',_binary '',4),(5,'2025-04-03 15:37:11.000000','2025-04-04 07:51:07.673129','반려동물 등록제, 저는 찬성이에요. 책임감 있게 키우는 문화가 자리 잡아야 한다고 생각해요.',8,2,'반려동물 등록제, 여러분 생각은?','PNTR',_binary '',5),(26,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','제가 매일 하는 운동 루틴입니다.',12,3,'운동 루틴 공유','INSB',_binary '',39),(27,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','서울숲 정말 좋아요!',8,5,'산책하기 좋은 장소','INSB',_binary '',2),(28,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','아침은 오트밀, 점심은 닭가슴살 추천!',20,2,'건강을 위한 식단 추천','ICTR',_binary '',3),(29,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','하루 만보 걷기가 건강에 얼마나 좋은지 아시나요?',15,1,'걷기의 중요성','INSR',_binary '',4),(30,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','이 영상 보고 허리 통증이 줄었어요.',5,4,'스트레칭 영상 추천','PNTB',_binary '',6),(31,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','한강 러닝 추천해요!',7,0,'내가 좋아하는 러닝 코스','INSB',_binary '',39),(32,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','비 오는 날에도 걷는 거 좋아하시나요?',3,1,'비 오는 날 걷기','INSB',_binary '',2),(33,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','드디어 30일 연속 달성!',25,6,'애플워치 목표 달성!','ICTR',_binary '',39),(34,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','건강을 위해 더 중요한 건 무엇일까요?',9,2,'식단 vs 운동','INSR',_binary '',4),(35,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','이 앱으로 목표 달성률 확인 가능해요.',11,3,'건강앱 추천해요','PNTB',_binary '',6),(36,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','여러분은 어떤 걸 더 선호하시나요?',6,0,'헬스장 vs 야외운동','INSB',_binary '',1),(37,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','사람도 적고 공기도 좋고 최고예요.',4,2,'밤 산책의 매력','INSB',_binary '',2),(38,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','스트레칭 꼭 하세요!',2,0,'무릎 통증 조심하세요','ICTR',_binary '',3),(39,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','걷기만큼 수분 보충도 중요해요.',13,1,'물 많이 마시기','INSR',_binary '',4),(40,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','편한 신발이 정말 중요해요.',3,1,'발바닥 통증 해결법','PNTB',_binary '',6),(41,'2025-04-04 17:55:37.000000','2025-04-04 17:55:37.000000','함께 걷거나 러닝 하실 분?',10,2,'주말 운동 모임 구해요','INSB',_binary '',1),(42,'2025-04-04 17:55:37.000000','2025-04-10 06:29:45.786414','3일 연속 성공했어요.',17,4,'하루 1만보 성공!','INSB',_binary '',2),(43,'2025-04-04 17:55:37.000000','2025-04-10 06:29:45.802976','비트 빠른 음악 추천해요!',6,0,'걷기 중 음악 추천','ICTR',_binary '',3),(44,'2025-04-04 17:55:37.000000','2025-04-10 06:19:45.787447','기록 남기기 정말 좋아요.',7,3,'걷기 기록 어플 추천','INSR',_binary '',4),(45,'2025-04-04 17:55:37.000000','2025-04-10 06:14:45.807184','작은 습관이 큰 변화를 만듭니다.',18,5,'건강한 삶을 위하여','PNTB',_binary '',6),(60,'2025-04-10 06:10:42.249537','2025-04-10 06:10:42.249537','요즘 절대평가 얘기가 많던데, 저도 수험생일 땐 진짜 상대평가가 너무 스트레스였어요. 바뀌면 좋겠네요.',0,0,'절대평가 정말 필요할까요?','COMMON',_binary '',6);
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 15:50:04
