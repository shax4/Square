CREATE DATABASE  IF NOT EXISTS `square_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `square_db`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: j12a307.p.ssafy.io    Database: square_db
-- ------------------------------------------------------
-- Server version	8.4.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `opinion`
--

DROP TABLE IF EXISTS `opinion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opinion` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `comment_count` int NOT NULL,
  `content` varchar(255) NOT NULL,
  `is_left` bit(1) NOT NULL,
  `like_count` int NOT NULL,
  `is_valid` bit(1) NOT NULL,
  `debate_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKhwfnrn21uwxp6en5pohsfp4aj` (`debate_id`),
  KEY `FKnifwjuxuse33c615nw3cb6r7x` (`user_id`),
  CONSTRAINT `FKhwfnrn21uwxp6en5pohsfp4aj` FOREIGN KEY (`debate_id`) REFERENCES `debate` (`id`),
  CONSTRAINT `FKnifwjuxuse33c615nw3cb6r7x` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opinion`
--

LOCK TABLES `opinion` WRITE;
/*!40000 ALTER TABLE `opinion` DISABLE KEYS */;
INSERT INTO `opinion` VALUES (122,'2025-03-04 17:18:00.000000','2025-04-11 00:16:08.850529',0,'요즘 유기동물 문제 너무 심각합니다. 최소한 등록은 의무로 가야죠.',_binary '',1,_binary '',70,39),(123,'2025-03-10 17:18:34.000000','2025-03-10 17:18:42.000000',0,'책임감 없이 키우는 사람들 너무 많아요. 등록제가 당연한 수순이라 봅니다.',_binary '',0,_binary '',70,3),(124,'2025-04-01 17:18:49.000000','2025-04-11 00:16:08.866617',1,'등록해야 관리도 되고 정책도 세울 수 있죠. 반대하는 이유를 모르겠네요.',_binary '',0,_binary '',70,6),(125,'2025-04-06 17:19:12.000000','2025-04-11 00:11:08.844237',1,'정부가 또 감시하려는 거 아닌가요? 솔직히 부담만 늘어나는 느낌입니다.',_binary '\0',1,_binary '',70,39),(131,'2025-04-10 17:19:20.000000',NULL,0,'취지는 알겠지만, 모든 사람에게 의무화는 좀 과하다고 생각합니다.',_binary '\0',0,_binary '',70,5),(132,'2025-03-04 17:18:00.000000',NULL,0,'요즘 악플 너무 심해요. 실명제라도 도입해서 좀 줄여야 하지 않나요?',_binary '',0,_binary '',67,1),(133,'2025-03-10 17:18:34.000000',NULL,0,'익명 뒤에 숨어서 막말하는 사람들 보면 실명제가 필요하다고 느껴요.',_binary '',0,_binary '',67,39),(134,'2025-04-01 17:18:49.000000',NULL,0,'실명제 한다고 악플이 사라질까요? 표현의 자유만 침해될 듯.',_binary '\0',0,_binary '',67,2),(135,'2025-04-06 17:19:12.000000',NULL,0,'정부 감시만 심해질 거 같아요. 더 무서운 세상 되는 거 아닌가요?',_binary '\0',0,_binary '',67,5),(136,'2025-04-10 17:19:20.000000',NULL,0,'익명성이 있어야 진짜 말도 나올 수 있는 거 아닌가요?',_binary '\0',0,_binary '',67,3),(137,'2025-03-04 17:18:00.000000',NULL,0,'일만 하다 인생 끝날 것 같아요. 주 4일제 꼭 좀 도입해 주세요.',_binary '',0,_binary '',65,39),(138,'2025-03-10 17:18:34.000000',NULL,0,'시간 줄어도 효율만 올라가면 되죠. 결국 일은 사람이 하는 거니까요.',_binary '',0,_binary '',65,3),(139,'2025-04-01 17:18:49.000000',NULL,0,'금요일마다 눈치 안 보고 쉴 수 있다면 삶의 질이 엄청 올라갈 듯.',_binary '',0,_binary '',65,4),(140,'2025-04-06 17:19:12.000000','2025-04-11 00:16:08.826709',0,'실제로 몇몇 기업은 이미 하고 있고 효과도 좋다는 사례 많잖아요.',_binary '',2,_binary '',65,6),(141,'2025-04-10 17:19:20.000000','2025-04-11 04:43:47.740903',0,'듣기엔 좋아 보이지만 현실은 야근 늘어나고 주말에도 일할 듯요.',_binary '\0',1,_binary '',65,2),(158,'2025-04-10 13:16:13.555791','2025-04-11 00:11:08.864500',0,'반려동물 등록은 무조건 자율화해야지요!',_binary '\0',1,_binary '',70,34),(159,'2025-04-11 02:09:45.458332','2025-04-11 02:09:45.458332',0,'정부가 또 감시하려는 거 아닌가요? 솔직히 부담만 늘어나는 느낌입니다.',_binary '\0',0,_binary '',70,2),(160,'2025-04-11 02:09:55.535710','2025-04-11 02:09:55.535710',0,'정부가 또 감시하려는 거 아닌가요? 솔직히 부담만 늘어나는 느낌입니다.',_binary '\0',0,_binary '',70,2),(161,'2025-04-11 02:10:15.166587','2025-04-11 02:10:15.166587',0,'정부가 또 감시하려는 거 아닌가요? 솔직히 부담만 늘어나는 느낌입니다.',_binary '\0',0,_binary '',70,2),(162,'2025-04-11 02:10:19.141200','2025-04-11 02:10:19.141200',0,'정부가 또 감시하려는 거 아닌가요? 솔직히 부담만 늘어나는 느낌입니다.',_binary '\0',0,_binary '',70,2),(163,'2025-04-11 02:10:53.215139','2025-04-11 02:10:53.215139',0,'정부가 또 감시하려는 거 아닌가요? 솔직히 부담만 늘어나는 느낌입니다.',_binary '\0',0,_binary '',70,2);
/*!40000 ALTER TABLE `opinion` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 15:50:01
